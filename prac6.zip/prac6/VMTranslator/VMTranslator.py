def reformatSegment(segment, offset):
    if (segment == "this"):
        return "THIS"

    if (segment == "that"):
        return "THAT"

    if (segment == "argument"):
        return "ARG"
    
    if (segment == "local"):
        return "LCL"
    
    if (segment == "static"):
        return str(16+offset)

    if (segment == "pointer"):
        return "R" + str(3 + offset)

    if (segment == "temp"):
        return "R" + str(5 + offset)

    if (segment == "constant"):
        return str(offset)
    
    return segment

class VMTranslator:
    labelCounter = 0
    
    def newLabel():
        assemblyStr = str(VMTranslator.labelCounter)
        VMTranslator.labelCounter += 1
        return assemblyStr

    def vm_push(segment, offset):
        '''Generate Hack Assembly code for a VM push operation'''
        #reformat the segement and the offset into their Assembly equivalents
        memory_seg = reformatSegment(segment, offset)
        #intialise strings
        assemblyStr = ""
        

        #taking value from memory
        if(segment == "constant" or segment == "static" or segment == "pointer" or segment == "temp"):
            assemblyStr += "@" + memory_seg + "\n"

            #put value into D
            if segment == "constant":
                assemblyStr += "D = A\n"
            #put value at RAM[A] into D
            else:
                assemblyStr += "D = M\n"

        #taking a value from memory that is pointed to
        elif(segment == "local" or segment == "arguement" or segment == "this" or segment == "that"):
            assemblyStr += "@" + memory_seg + "\n"
            assemblyStr += "D = M \n"
            assemblyStr += "@" + str(offset) + "\n"
            assemblyStr += "A = D + A\n"
            assemblyStr += "D = M\n"
        
        #pushing value onto stack
        assemblyStr += "@SP\n"  #set A to the address of the stack pointer
        assemblyStr += "A = M\n" #set to the value stored at the stack pointer (top of the stack)
        assemblyStr += "M = D\n" #store the value in D at the top of the stack so RAM[256] = D
        assemblyStr += "@SP\n" #set A to the address of the stack pointer
        assemblyStr += "M = M + 1" #increment the stack pointer
        
        return assemblyStr

    def vm_pop(segment, offset):
        '''Generate Hack Assembly code for a VM pop operation'''
        memory_seg = reformatSegment(segment, offset)

        #get base address of memory segment
        assemblyStr = "@" + memory_seg + "\n"
        
        #base address is the direct memory location for static, temp or pointer
        if (segment == "static" or segment == "temp" or segment == "pointer"):
            assemblyStr += "D = A\n" #store base address

        #must take base address and offset for local, this, that or argument
        elif (segment == "local" or segment == "this" or segment == "that" or segment == "argument"):
            assemblyStr += "D = M\n" #store base address
            assemblyStr += "@" + str(offset) + "\n" #offset
            assemblyStr += "D = D + A\n" # D = base address + offset

        assemblyStr += "@R13\n"
        assemblyStr += "M = D\n" #store target memory address in R13
        assemblyStr += "@SP\n" 
        assemblyStr += "AM = M -1\n" #decrement stack pointer
        assemblyStr += "D = M\n" #D = value at top of stack
        assemblyStr += "@R13\n" 
        assemblyStr += "A=M\n" #target address
        assemblyStr += "M=D" #popped value stored in target address

        return assemblyStr


    def vm_add():
        '''Generate Hack Assembly code for a VM add operation'''
        #take top and second value from stack and add together
       
        assemblyStr = "@SP\n"
        assemblyStr += "AM = M -1\n" #move stack pointer down
        assemblyStr += "D = M\n" #store top value in D]
        assemblyStr += "A = A -1 \n" # A = SP -1, A points to second top value on stack
        assemblyStr += "M = D + M" # RAM[SP - 1] = D + RAM[SP - 1] (Add top two values and store result).

        return assemblyStr

    def vm_sub():
        '''Generate Hack Assembly code for a VM sub operation'''
        #take top (x) and second (y) values from stack and substact, y - x
     
        assemblyStr = "@SP\n"
        assemblyStr += "AM = M -1\n" #move stack pointer down
        assemblyStr += "D = M\n" #store top value in D]
        assemblyStr += "A = A -1 \n" # A = SP -1, A points to second top value on stack
        assemblyStr += "M = M - D" # RAM[SP - 1] = D + RAM[SP - 1] (Add top two values and store result).
        return assemblyStr

    def vm_neg():
        '''Generate Hack Assembly code for a VM neg operation'''
      
        assemblyStr = "@SP\n"
        assemblyStr += "A = M -1\n" #A points to value on top of the stack  
        assemblyStr += "M = !M\n" #negate top value of stack
        assemblyStr += "M = M + 1" #add one because hack uses 2's complement
        return assemblyStr

    def vm_eq():
        '''Generate Hack Assembly code for a VM eq operation'''
        #take top two values from stack and check if they are equal
        label = VMTranslator.newLabel()
        assemblyStr = ""
        assemblyStr += "@SP\n"
        assemblyStr += "AM = M - 1\n" #decrement stack pointer
        assemblyStr += "D = M\n" #store top value in D
        assemblyStr += "A = A -1\n" # A points to second top value
        assemblyStr += "D = M - D\n" # D = second value - top value

        #check if the result is zero
        assemblyStr += "@EQUALS" + label + "\n"
        assemblyStr += "D;JEQ\n"

        #result isn't zero, values not equal, push zero to top of stack
        assemblyStr += "@SP\n" 
        assemblyStr += "A = M - 1\n"
        assemblyStr += "M = 0\n" 
        #skip to the end
        assemblyStr += "@SKIP" + label + "\n"
        assemblyStr += "0;JMP\n"
        
        #result is zero, values are equal, push -1 onto top of stack
        assemblyStr += "(@EQUALS" + label + ")\n"
        assemblyStr += "@SP\n"
        assemblyStr += "A = M -1\n"
        assemblyStr += "M = -1\n"
        
        assemblyStr += "(SKIP" + label + ")"
        return assemblyStr

    def vm_gt():
        '''Generate Hack Assembly code for a VM gt operation'''
        #check if second top is greater than top value
        label = VMTranslator.newLabel()
      
        assemblyStr = "@SP\n"
        assemblyStr += "AM = M - 1\n" #decrement stack pointer
        assemblyStr += "D = M\n" #store top value in D
        assemblyStr += "A = A -1\n" # A points to second top value
        assemblyStr += "D = M - D\n" # D = second value - top value

        #check if the result is > 0
        assemblyStr += "@Greater" + label + "\n"
        assemblyStr += "D;JGT\n"

        #result < 0. push zero to top of stack
        assemblyStr += "@SP\n" 
        assemblyStr += "A = M - 1\n"
        assemblyStr += "M = 0\n" 
        #skip to the end
        assemblyStr += "@SKIP" + label + "\n"
        assemblyStr += "0;JMP\n"
        
        #result > 0, push -1 onto top of stack
        assemblyStr += "(@Greater" + label + ")\n"
        assemblyStr += "@SP\n"
        assemblyStr += "A = M -1\n"
        assemblyStr += "M = -1\n"
        
        assemblyStr += "(SKIP" + label + ")"
        return assemblyStr

    def vm_lt():
        '''Generate Hack Assembly code for a VM lt operation'''
       #check if second top is less than top value
        label = VMTranslator.newLabel()
        assemblyStr = "@SP\n"
        assemblyStr += "AM = M - 1\n" #decrement stack pointer
        assemblyStr += "D = M\n" #store top value in D
        assemblyStr += "A = A -1\n" # A points to second top value
        assemblyStr += "D = M - D\n" # D = second value - top value

        #check if the result is > 0
        assemblyStr += "@Lesser" + label + "\n"
        assemblyStr += "D;JLT\n"

        #result > 0. push zero to top of stack
        assemblyStr += "@SP\n" 
        assemblyStr += "A = M - 1\n"
        assemblyStr += "M = 0\n" 
        #skip to the end
        assemblyStr += "@SKIP" + label + "\n"
        assemblyStr += "0;JMP\n"
        
        #result < 0, push -1 onto top of stack
        assemblyStr += "(@Lesser" + label + ")\n"
        assemblyStr += "@SP\n"
        assemblyStr += "A = M -1\n"
        assemblyStr += "M = -1\n"
        
        assemblyStr += "(SKIP" + label + ")"
        return assemblyStr

    def vm_and():
        '''Generate Hack Assembly code for a VM and operation'''
        assemblyStr = "@SP\n"
        assemblyStr += "AM = M - 1\n" #decrement stack pointer
        assemblyStr += "D = M\n" # D = top value
        assemblyStr += "A = A -1\n" #A points to second top value
        assemblyStr += "M = M&D" #using in built assembly function
        return assemblyStr

    def vm_or():
        '''Generate Hack Assembly code for a VM or operation'''
        assemblyStr = "@SP\n"
        assemblyStr += "AM = M - 1\n" #decrement stack pointer
        assemblyStr += "D = M\n" # D = top value
        assemblyStr += "A = A -1\n" #A points to second top value
        assemblyStr += "M = M|D" #using in built assembly function
        return assemblyStr

    def vm_not():
        '''Generate Hack Assembly code for a VM not operation'''
        assemblyStr = "A = M -1\n" #A points to top value on stack
        assemblyStr += "M = !M\n" #notting it
        return assemblyStr

    def vm_label(label):
        '''Generate Hack Assembly code for a VM label operation'''
        assemblyStr = "(" + label + ")"
        return assemblyStr

    def vm_goto(label):
        '''Generate Hack Assembly code for a VM goto operation'''
        assemblyStr = "@" + label + "\n"
        assemblyStr += "0;JMP"
        return assemblyStr

    def vm_if(label):
        '''Generate Hack Assembly code for a VM if-goto operation'''
        #jump to label if the prior function has returned true (-1)
        assemblyStr = "@SP\n"
        assemblyStr += "AM = M -1\n" #move the SP down
        assemblyStr += "D = M\n" #store value at the top of the stack in D
        assemblyStr += "@" + label + "\n"
        assemblyStr += "D;JNE" #jump if the prior function has not returned 0
        return assemblyStr

    def vm_function(function_name, n_vars):
        '''Generate Hack Assembly code for a VM function operation'''
        #voodoo shit, creates a jump label with the function name
        assemblyStr = "(FUNC.defMod. " + function_name + ")\n"

        
        assemblyStr += "@SP\n"
        assemblyStr += "A = M\n" #A points to the SP

        for i in range(n_vars):
            #intialise local variables to 0
            assemblyStr += "M = 0\n"
            assemblyStr += "A = A + 1\n"

        assemblyStr += "D = A\n" #storing new SP location in D
        assemblyStr += "@SP\n"
        assemblyStr += "M = D" #updating SP

        return assemblyStr

    def vm_call(function_name, n_args):
        '''Generate Hack Assembly code for a VM call operation'''
        label = VMTranslator.newLabel()

        assemblyStr = "@SP\n"
        assemblyStr += "D=M\n"
        assemblyStr += "@R13\n"
        assemblyStr += "M=D\n"
        
        assemblyStr += "@RET."+label+"\n"
        assemblyStr += "D=A\n"
        assemblyStr += "@SP\n"
        assemblyStr += "A=M\n"
        assemblyStr += "M=D\n"

        assemblyStr += "@SP\n"
        assemblyStr += "M=M+1\n"

        assemblyStr += "@LCL\n"
        assemblyStr += "D=M\n"
        assemblyStr += "@SP\n"
        assemblyStr += "A=M\n"
        assemblyStr += "M=D\n"

        assemblyStr += "@SP\n"
        assemblyStr += "M=M+1\n"

        assemblyStr += "@ARG\n"
        assemblyStr += "D=M\n"
        assemblyStr += "@SP\n"
        assemblyStr += "A=M\n"
        assemblyStr += "M=D\n"
        
        assemblyStr += "@SP\n"
        assemblyStr += "M=M+1\n"

        assemblyStr += "@THIS\n"
        assemblyStr += "D=M\n"
        assemblyStr += "@SP\n"
        assemblyStr += "A=M\n"
        assemblyStr += "M=D\n"

        assemblyStr += "@SP\n"
        assemblyStr += "M=M+1\n"

        assemblyStr += "@THAT\n"
        assemblyStr += "D=M\n"
        assemblyStr += "@SP\n"
        assemblyStr += "A=M\n"
        assemblyStr += "M=D\n"

        assemblyStr += "@SP\n"
        assemblyStr += "M=M+1\n"

        assemblyStr += "@R13\n"
        assemblyStr += "D=M\n"
        assemblyStr += "@"+str(n_args)+"\n"
        assemblyStr += "D=D-A\n"
        assemblyStr += "@ARG\n"
        assemblyStr += "M=D\n"

        assemblyStr += "@SP\n"
        assemblyStr += "D=M\n"
        assemblyStr += "@LCL\n"
        assemblyStr += "M=D\n"
        assemblyStr += "@FUNC.defMod." + function_name + "\n"
        assemblyStr += "0;JMP\n"
        assemblyStr += "(RET."+ label + ")"

        
        return assemblyStr

    def vm_return():
        '''Generate Hack Assembly code for a VM return operation'''
        assemblyStr = "@LCL\n"
        assemblyStr += "D=M\n"
        assemblyStr += "@5\n"
        assemblyStr += "A=D-A\n"
        assemblyStr += "D=M\n"
        assemblyStr += "@R13\n"
        assemblyStr += "M=D\n"


        assemblyStr += "@SP\n"
        assemblyStr += "A=M-1\n"
        assemblyStr += "D=M\n"
        assemblyStr += "@ARG\n"
        assemblyStr += "A=M\n"
        assemblyStr += "M=D\n"


        assemblyStr += "D=A+1\n"
        assemblyStr += "@SP\n"
        assemblyStr += "M=D\n"


        assemblyStr += "@LCL\n"
        assemblyStr += "AM=M-1\n"
        assemblyStr += "D=M\n"
        assemblyStr += "@THAT\n"
        assemblyStr += "M=D\n"


        assemblyStr += "@LCL\n"
        assemblyStr += "AM=M-1\n"
        assemblyStr += "D=M\n"
        assemblyStr += "@THIS\n"
        assemblyStr += "M=D\n"

        assemblyStr += "@LCL\n"
        assemblyStr += "AM=M-1\n"
        assemblyStr += "D=M\n"
        assemblyStr += "@ARG\n"
        assemblyStr += "M=D\n"

        assemblyStr += "@LCL\n"
        assemblyStr += "A=M-1\n"
        assemblyStr += "D=M\n"
        assemblyStr += "@LCL\n"
        assemblyStr += "M=D\n"

        assemblyStr += "@R13\n"
        assemblyStr += "A=M\n"
        assemblyStr += "0;JMP"

        return assemblyStr

# A quick-and-dirty parser when run as a standalone script.
if __name__ == "__main__":
    import sys
    if(len(sys.argv) > 1):
        with open(sys.argv[1], "r") as a_file:
            for line in a_file:
                tokens = line.strip().lower().split()
                if(len(tokens)==1):
                    if(tokens[0]=='add'):
                        print(VMTranslator.vm_add())
                    elif(tokens[0]=='sub'):
                        print(VMTranslator.vm_sub())
                    elif(tokens[0]=='neg'):
                        print(VMTranslator.vm_neg())
                    elif(tokens[0]=='eq'):
                        print(VMTranslator.vm_eq())
                    elif(tokens[0]=='gt'):
                        print(VMTranslator.vm_gt())
                    elif(tokens[0]=='lt'):
                        print(VMTranslator.vm_lt())
                    elif(tokens[0]=='and'):
                        print(VMTranslator.vm_and())
                    elif(tokens[0]=='or'):
                        print(VMTranslator.vm_or())
                    elif(tokens[0]=='not'):
                        print(VMTranslator.vm_not())
                    elif(tokens[0]=='return'):
                        print(VMTranslator.vm_return())
                elif(len(tokens)==2):
                    if(tokens[0]=='label'):
                        print(VMTranslator.vm_label(tokens[1]))
                    elif(tokens[0]=='goto'):
                        print(VMTranslator.vm_goto(tokens[1]))
                    elif(tokens[0]=='if-goto'):
                        print(VMTranslator.vm_if(tokens[1]))
                elif(len(tokens)==3):
                    if(tokens[0]=='push'):
                        print(VMTranslator.vm_push(tokens[1],int(tokens[2])))
                    elif(tokens[0]=='pop'):
                        print(VMTranslator.vm_pop(tokens[1],int(tokens[2])))
                    elif(tokens[0]=='function'):
                        print(VMTranslator.vm_function(tokens[1],int(tokens[2])))
                    elif(tokens[0]=='call'):
                        print(VMTranslator.vm_call(tokens[1],int(tokens[2])))

        